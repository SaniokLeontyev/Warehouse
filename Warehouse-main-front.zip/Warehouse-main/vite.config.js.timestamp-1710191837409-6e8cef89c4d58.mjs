// vite.config.js
import { defineConfig } from "file:///D:/%D0%A0%D0%B0%D0%B1%20%D1%81%D1%82%D0%BE%D0%BB%202023/skald-admin/sklad-admin/node_modules/vite/dist/node/index.js";
import { qrcode } from "file:///D:/%D0%A0%D0%B0%D0%B1%20%D1%81%D1%82%D0%BE%D0%BB%202023/skald-admin/sklad-admin/node_modules/vite-plugin-qrcode/dist/index.js";
import react from "file:///D:/%D0%A0%D0%B0%D0%B1%20%D1%81%D1%82%D0%BE%D0%BB%202023/skald-admin/sklad-admin/node_modules/@vitejs/plugin-react/dist/index.mjs";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    qrcode()
  ]
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCJEOlxcXFxcdTA0MjBcdTA0MzBcdTA0MzEgXHUwNDQxXHUwNDQyXHUwNDNFXHUwNDNCIDIwMjNcXFxcc2thbGQtYWRtaW5cXFxcc2tsYWQtYWRtaW5cIjtjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfZmlsZW5hbWUgPSBcIkQ6XFxcXFx1MDQyMFx1MDQzMFx1MDQzMSBcdTA0NDFcdTA0NDJcdTA0M0VcdTA0M0IgMjAyM1xcXFxza2FsZC1hZG1pblxcXFxza2xhZC1hZG1pblxcXFx2aXRlLmNvbmZpZy5qc1wiO2NvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9pbXBvcnRfbWV0YV91cmwgPSBcImZpbGU6Ly8vRDovJUQwJUEwJUQwJUIwJUQwJUIxJTIwJUQxJTgxJUQxJTgyJUQwJUJFJUQwJUJCJTIwMjAyMy9za2FsZC1hZG1pbi9za2xhZC1hZG1pbi92aXRlLmNvbmZpZy5qc1wiO2ltcG9ydCB7IGRlZmluZUNvbmZpZyB9IGZyb20gJ3ZpdGUnXG5pbXBvcnQgeyBxcmNvZGUgfSBmcm9tICd2aXRlLXBsdWdpbi1xcmNvZGUnO1xuaW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0J1xuXG4vLyBodHRwczovL3ZpdGVqcy5kZXYvY29uZmlnL1xuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29uZmlnKHtcbiAgcGx1Z2luczogW1xuICAgIHJlYWN0KCksXG4gICAgcXJjb2RlKClcbiAgXSxcbn0pXG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQXlWLFNBQVMsb0JBQW9CO0FBQ3RYLFNBQVMsY0FBYztBQUN2QixPQUFPLFdBQVc7QUFHbEIsSUFBTyxzQkFBUSxhQUFhO0FBQUEsRUFDMUIsU0FBUztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBLEVBQ1Q7QUFDRixDQUFDOyIsCiAgIm5hbWVzIjogW10KfQo=
