export const GET_TASK = 'GET_TASK' // получение списка задач
export const ALL_UUID = 'ALL_UUID' // из 1С 
export const GET_SELECTED_SHELVES = 'GET_SELECTED_SHELVES'