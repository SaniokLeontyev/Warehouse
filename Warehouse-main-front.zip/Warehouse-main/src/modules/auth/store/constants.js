export const USER_LOGIN = 'USER_LOGIN'
export const CLEAN_USER = 'CLEAN_USER'
export const SET_ROLE = 'SET_ROLE'