export const DELETE_USER = 'DELETE_USER'
export const GET_ALL_USER = 'GET_ALL_USER'
export const GET_ALL_ROLE = 'GET_ALL_ROLE'
export const EDIT_USER = 'EDIT_USER'
export const GET_USER_BY_ID = 'GET_USER_BY_ID'

// export const ROLE_NAMES = [
//     {
//         ADMINISTRATOR: "Администратор"
//     },
//     {
//         WAREHOUSE_MANAGER: "Заведующий складом"
//     },
//     {
//         STOREKEEPER: "Кладовщик"
//     },
//     {
//         PICKER: "Комплектовщик"
//     },
//     {
//         FORKLIFT_DRIVER: "Карщик"
//     },
//     {
//         LOADER: "Грузчик"
//     },
//     {
//         WAREHOUSE_AUDITOR: "Аудитор"
//     }
// ]