Warehouse managering system

Starting instruction in file WarehouseManager Manual.docx
Project dependencies:
  - Java version 13
  - Spring boot version 2.5.2
  - spring-boot-starter-data-jpa
  - spring-boot-starter-web
  - postgresql
  - lombok
  - spring-boot-starter-test
  - springfox-boot-starter
  - springfox-swagger-ui
  - spring-boot-starter-security
  - jjwt
  - jaxb-api
