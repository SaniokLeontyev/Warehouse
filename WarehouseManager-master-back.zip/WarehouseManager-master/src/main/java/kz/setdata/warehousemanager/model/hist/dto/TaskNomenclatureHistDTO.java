package kz.setdata.warehousemanager.model.hist.dto;

import lombok.Data;

@Data
public class TaskNomenclatureHistDTO {
    private NomenclatureHistDTO nomenclatureHistDTO;
    private int quantity;
}
