package kz.setdata.warehousemanager.controller.constructor;

import io.swagger.annotations.Api;
import kz.setdata.warehousemanager.model.dto.constructor.ConstructorDTO;
import kz.setdata.warehousemanager.model.dto.general.ResponseDto;
import kz.setdata.warehousemanager.service.constructor.WarehouseWindowsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/warehouse/windows")
@Api(value = "Operations related to windows", tags = {"Windows"})
@RequiredArgsConstructor
public class WarehouseWindowsController {

    private final WarehouseWindowsService warehouseWindowsService;

    @GetMapping
    public ResponseEntity<ResponseDto> getAll(){
        return ResponseEntity.ok(ResponseDto.success(warehouseWindowsService.getAll()));
    }

    @PutMapping("/{constructorId}")
    public ResponseEntity<ResponseDto> save(@RequestBody ConstructorDTO constructorDTO, @PathVariable long constructorId){
        return ResponseEntity.ok(ResponseDto.success(warehouseWindowsService.save(constructorDTO, constructorId)));
    }

    @PatchMapping
    public ResponseEntity<ResponseDto> update(@RequestBody ConstructorDTO constructorDTO){
        return ResponseEntity.ok(ResponseDto.success(warehouseWindowsService.update(constructorDTO)));
    }

    @DeleteMapping
    public ResponseEntity<ResponseDto> delete(@RequestBody List<Long> windows){
        return ResponseEntity.ok(ResponseDto.success(warehouseWindowsService.delete(windows)));
    }

}
