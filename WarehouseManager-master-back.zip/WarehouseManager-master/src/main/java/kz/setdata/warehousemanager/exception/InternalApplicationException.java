package kz.setdata.warehousemanager.exception;

public class InternalApplicationException extends RuntimeException{
    public InternalApplicationException(String message){
        super(message);
    }
}
