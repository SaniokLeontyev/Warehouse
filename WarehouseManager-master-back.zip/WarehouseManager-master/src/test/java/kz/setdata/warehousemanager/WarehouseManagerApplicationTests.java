package kz.setdata.warehousemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
